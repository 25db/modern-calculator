package com.example.moderncalculator

import com.example.moderncalculator.ui.CalcState

// 纯逻辑单测，不需要 Android 设备
class CalcLogicTest {

    private fun s() = CalcState().also { }

    @org.junit.Test
    fun `addition`() {
        val c = CalcState()
        c.inputDigit('1'); c.inputDigit('2')
        c.applyOp('+'); c.inputDigit('3')
        c.equals()
        check(c.display == "15") { "expected 15 got ${c.display}" }
        check(c.history == "12 + 3 =")
    }

    @org.junit.Test
    fun `division by zero`() {
        val c = CalcState()
        c.inputDigit('5')
        c.applyOp('÷'); c.inputDigit('0')
        c.equals()
        check(c.display == "Error")
    }

    @org.junit.Test
    fun `clear resets`() {
        val c = CalcState()
        c.inputDigit('9'); c.applyOp('+'); c.inputDigit('9')
        c.clear()
        check(c.display == "0")
        check(c.history.isBlank())
    }

    @org.junit.Test
    fun `toggle sign`() {
        val c = CalcState()
        c.inputDigit('5'); c.toggleSign()
        check(c.display == "-5")
        c.toggleSign()
        check(c.display == "5")
    }

    @org.junit.Test
    fun `backspace negative`() {
        val c = CalcState()
        c.inputDigit('5'); c.toggleSign()
        c.backspace()
        check(c.display == "0")
    }

    @org.junit.Test
    fun `operator chain`() {
        val c = CalcState()
        c.inputDigit('2'); c.applyOp('×'); c.inputDigit('3'); c.equals()
        c.inputDigit('4'); c.equals() // 2*3=6, 6+? 无 op
        // 无 pendingOp 时 equals 无效
        check(c.display == "6" || c.display == "24")
    }

    @org.junit.Test
    fun `point only once`() {
        val c = CalcState()
        c.inputDigit('1'); c.inputPoint()
        check(c.display == "1.")
        c.inputPoint()
        check(c.display == "1.")
    }
}
